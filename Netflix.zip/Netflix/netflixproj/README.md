# Netflix EDA Project

## Overview
This project performs Exploratory Data Analysis on Netflix Movies and TV Shows dataset.

## Objectives
- Analyze genre distribution
- Study year-wise growth
- Identify top producing countries
- Analyze ratings
- Study movie duration patterns

## Tools Used
- Python
- Pandas
- Matplotlib
- Seaborn

## Project Structure
- data/ → Raw dataset
- notebooks/ → Jupyter Notebook
- images/ → Saved visualizations
- requirements.txt → Dependencies

## Key Insights
- Movies dominate the platform.
- Content growth increased after 2015.
- USA leads in content production.
- Drama is most popular genre.

## How to Run
1. Install requirements:
   pip install -r requirements.txt
2. Run notebook inside notebooks folder.
